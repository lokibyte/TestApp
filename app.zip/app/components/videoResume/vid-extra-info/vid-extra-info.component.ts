import { Component, OnInit } from '@angular/core';
import { MediaCapture, MediaFile, CaptureError, CaptureImageOptions,CaptureVideoOptions}  from '@awesome-cordova-plugins/media-capture/ngx'
import { Capacitor } from '@capacitor/core';

@Component({
  selector: 'app-vid-extra-info',
  templateUrl: './vid-extra-info.component.html',
  styleUrls: ['./vid-extra-info.component.scss'],
})
export class VidExtraInfoComponent  implements OnInit {

  urlextrainfoVideo='';
  constructor(public mediaCapture: MediaCapture) { }

  ngOnInit() {
    this.urlextrainfoVideo = Capacitor.convertFileSrc(localStorage.getItem('extrainfovideo') || "")
    console.info("ngOnInit-extra");
    let vid = document.getElementById('extrainfo-recorded');
    
    vid!.onloadstart=function(){
      alert("loadstart");
    }
    
    vid!.onloadeddata = function() {
      alert("Browser has loaded the current frame");
    };
  }

  recordExtraInfoVideo(){
    console.info("recordExtraInfoVideo");
    let me = this;
    let options: CaptureVideoOptions = { duration: 180 } //3mins
		    this.mediaCapture.captureVideo(options)
		    .then(
		      (data:any) => {
            // console.log(data);
            me.urlextrainfoVideo = Capacitor.convertFileSrc(data[0].fullPath);
            localStorage.setItem('extrainfovideo',data[0].fullPath);
          },
		      (err) => console.error(err)
		    );
  }
  playVideo(){
    console.info("playVideo");
  }
  
  stopVideo(){
   console.info("stopVideo");
  }
}
