import { Component, OnInit } from '@angular/core';
import { MediaCapture, MediaFile, CaptureError, CaptureImageOptions,CaptureVideoOptions}  from '@awesome-cordova-plugins/media-capture/ngx'
import { Capacitor } from '@capacitor/core';

@Component({
  selector: 'app-vid-educational',
  templateUrl: './vid-educational.component.html',
  styleUrls: ['./vid-educational.component.scss'],
})
export class VidEducationalComponent  implements OnInit {

  urleducationVideo='';
  constructor(public mediaCapture: MediaCapture) { }

  ngOnInit() {
    this.urleducationVideo = Capacitor.convertFileSrc(localStorage.getItem('eduvideo') || "")
     
    console.info("ngOnInit-educational");
    let vid = document.getElementById('education-recorded');
    
    vid!.onloadstart=function(){
      alert("loadstart");
    }
    
    vid!.onloadeddata = function() {
      alert("Browser has loaded the current frame");
    };
  }

  recordEducationVideo(){
    console.info("recordEducationVideo");
    let me = this;
    let options: CaptureVideoOptions = { duration: 180 } //3mins
		    this.mediaCapture.captureVideo(options)
		    .then(
		      (data:any) => {
            // console.log(data);
            me.urleducationVideo = Capacitor.convertFileSrc(data[0].fullPath);
            localStorage.setItem('eduvideo',data[0].fullPath);
          },
		      (err) => console.error(err)
		    );
  }
  playVideo(){
    console.info("playVideo");
  }
  
  stopVideo(){
   console.info("stopVideo");
  }

}
