import { Component } from '@angular/core';
import { MediaCapture, MediaFile, CaptureError, CaptureImageOptions,CaptureVideoOptions}  from '@awesome-cordova-plugins/media-capture/ngx'
import { Capacitor } from '@capacitor/core';


@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {
  // recordedVideo:any;

  // currentcard = 1;
  // introductioncard = true;
  // personalcard = false;
  // educationcard = false;
  // skillcard = false;
  // extracard = false;

  // constructor(public mediaCapture: MediaCapture) {}
  // ionViewDidEnter(){
  //   // let url = "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4";
  //   // this.recordedVideo = document.getElementById('personal-recorded') as HTMLVideoElement;
  //   // this.recordedVideo.src = Capacitor.convertFileSrc(url);
  // }

  // record(){
  //   let me = this;
  //   console.info("record()");
  //   let options: CaptureVideoOptions = { duration: 180 } //3mins
	// 	    this.mediaCapture.captureVideo(options)
	// 	    .then(
	// 	      (data:any) => {
  //           // console.log(data);
  //           me.recordedVideo.src = Capacitor.convertFileSrc(data[0].fullPath);
  //         },
	// 	      (err) => console.error(err)
	// 	    );
  // }
  // stopVideo(){
  //   console.info("stopVideo");
  //   this.recordedVideo.pause()
  // }
  // replay(){
  //   console.info("replay");
  //   this.recordedVideo.play()
  // }
  // prevClick(prevcard:string){
  //   // console.info("prevClick",prevcard,this.currentcard);
  //   if(this.currentcard==1){
  //     this.introductioncard = false
  //   }else if(this.currentcard==2){
  //     console.info("personalcard3");
  //     this.personalcard =false;
  //   }else if(this.currentcard==3){
  //     this.educationcard =false;
  //     console.info("educationcard3");
  //   }else if(this.currentcard==5){
  //     console.info("extracard3");
  //     this.extracard =false;
  //   }else if(this.currentcard==4){
  //     console.info("skillcard3");
  //     this.skillcard =false;
  //   }
  //   this.currentcard--;
  // }
  // nextClick(nextcard:string){
  //   // console.info("nextClick",nextcard);
  //   // this.currentcard = nextcard;
  //   this.currentcard++;
  //   // console.info("nextcard2",this.currentcard);
    
  //   if(this.currentcard==1){
  //     this.introductioncard = true
  //   }else if(this.currentcard==2){
  //     this.personalcard =true;
  //   }else if(this.currentcard==3){
  //     this.educationcard =true;
      
  //   }else if(this.currentcard==4){
  //     this.skillcard =true;
      
  //   }else if(this.currentcard==5){
  //     this.extracard =true;
      
  //   }
    
  // }
  // submitClick(){
  //   console.info("submitClick",this.currentcard);
  
  // }
}
