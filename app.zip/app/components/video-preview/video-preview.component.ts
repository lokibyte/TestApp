import { Component, ElementRef, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ModalController } from '@ionic/angular';
@Component({
  selector: 'app-video-preview',
  templateUrl: './video-preview.component.html',
  styleUrls: ['./video-preview.component.scss'],
})
export class VideoPreviewComponent  implements OnInit {

  @ViewChild('previewcamera') camerVideoElementRef: ElementRef;
  videoElement: HTMLVideoElement;
  videos:any=[];
  constructor(private modalCtrl: ModalController) { }

  ngOnInit() {
    console.info("Previews",this.videos);
    this.nextVideo();
  }

currentVideo = 0;

async nextVideo() {
  let vid = document.getElementById('preview-videos') as HTMLVideoElement;
    // get the element
    let videoPlayer = vid;
    console.info("vid",vid);
    if (vid){
      // remove the event listener, if there is one
    videoPlayer.removeEventListener('ended',nextVideo,false);
// console.info("this.videos",this.videos[this.currentVideo][0]);
    // update the source with the currentVideo from the videos array
    // videoPlayer.src = this.videos[this.currentVideo];
    
    const videoBuffer = new Blob(this.videos[this.currentVideo], {
      type: 'video/webm'
    });
    let downloadUrl = window.URL.createObjectURL(videoBuffer); // you can download with <a> tag
    
    videoPlayer.srcObject = null;
    videoPlayer.src = downloadUrl;
    videoPlayer.muted = false;
    videoPlayer.controls = true;

    // play the video
    videoPlayer.play()

    // increment the currentVideo, looping at the end of the array
    this.currentVideo = (this.currentVideo + 1) % this.videos.length

    // add an event listener so when the video ends it will call the nextVideo function again
    videoPlayer.addEventListener('ended', nextVideo,false);
    }
    

    function nextVideo(){
      console.info("nextVideo");
    }
}
close(){
  this.modalCtrl.dismiss();
}

}
