import { Component, OnInit } from '@angular/core';
import { MediaCapture, MediaFile, CaptureError, CaptureImageOptions,CaptureVideoOptions}  from '@awesome-cordova-plugins/media-capture/ngx'
import { Capacitor } from '@capacitor/core';

@Component({
  selector: 'app-vid-personal',
  templateUrl: './vid-personal.component.html',
  styleUrls: ['./vid-personal.component.scss'],
})
export class VidPersonalComponent  implements OnInit {
  
  urlpersonalVideo=''
  // urlpersonalVideo = "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4";
  constructor(public mediaCapture: MediaCapture) { }

  ngOnInit() {
    this.urlpersonalVideo = Capacitor.convertFileSrc(localStorage.getItem('personalvideo') || this.urlpersonalVideo)
    console.info("ngOnInit-personal");
    let vid = document.getElementById('personal-recorded');
    
    vid!.onloadstart=function(){
      alert("loadstart");
    }
    
    vid!.onloadeddata = function() {
      alert("Browser has loaded the current frame");
    };
    
    console.info("vid",vid);
  }
  
  ionViewDidEnter(){
    console.info("ionViewDidEnter-personal");
  }
  recordPersonalVideo(){
    console.info("recordPersonalVideo");
    let me = this;
    let options: CaptureVideoOptions = { duration: 180 } //3mins
		    this.mediaCapture.captureVideo(options)
		    .then(
		      (data:any) => {
            // console.log(data);
            me.urlpersonalVideo = Capacitor.convertFileSrc(data[0].fullPath);
            localStorage.setItem('personalvideo',data[0].fullPath);
          },
		      (err) => console.error(err)
		    );
  }
  playVideo(){
    console.info("playVideo");
  }
  
  stopVideo(){
   console.info("stopVideo");
  }
}
