import { Component, ElementRef, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { VideoRecorderComponent } from '../components/video-recorder/video-recorder.component';
import { ModalController } from '@ionic/angular';
import { VideoPreviewComponent } from '../components/video-preview/video-preview.component';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page {
  @ViewChild('previewcamera', { static: false }) camerVideoElementRef: ElementRef;
  videoElement: HTMLVideoElement;

  educationVideo:any;

  recordedVideo:any;

  currentcard = 1;
  introductioncard = true;
  personalcard = false;
  educationcard = false;
  skillcard = false;
  extracard = false;

  videoBlobs: Array<Array<Blob>> = [];
  constructor(private modalCtrl: ModalController,) {}

  record(){
    let me = this;
    console.info("record()");
    
  }
  stopVideo(){
    console.info("stopVideo");
    this.recordedVideo.pause()
  }
  replay(){
    console.info("replay");
    this.recordedVideo.play()
  }
  prevClick(prevcard:string){
    // console.info("prevClick",prevcard,this.currentcard);
    if(this.currentcard==1){
      this.introductioncard = false
    }else if(this.currentcard==2){
      console.info("personalcard3");
      this.personalcard =false;
    }else if(this.currentcard==3){
      this.educationcard =false;
      console.info("educationcard3");
    }else if(this.currentcard==5){
      console.info("extracard3");
      this.extracard =false;
    }else if(this.currentcard==4){
      console.info("skillcard3");
      this.skillcard =false;
    }
    this.currentcard--;
  }
  nextClick(nextcard:string){
    // console.info("nextClick",nextcard);
    // this.currentcard = nextcard;
    this.currentcard++;
    // console.info("nextcard2",this.currentcard);
    
    if(this.currentcard==1){
      this.introductioncard = true
    }else if(this.currentcard==2){
      this.personalcard =true;
    }else if(this.currentcard==3){
      this.educationcard =true;
      
    }else if(this.currentcard==4){
      this.skillcard =true;
      
    }else if(this.currentcard==5){
      this.extracard =true;
      
    }
    
  }
  submitClick(){
    console.info("submitClick",this.currentcard);
  
  }
  async onPreview(recorder:VideoRecorderComponent){
    console.info("onPreview()",recorder.videoBlobs);
    
    const modal = await this.modalCtrl.create({
      component: VideoPreviewComponent,
      mode:'md',
      componentProps:{
        videos:recorder.videoBlobs
      }
    });
    modal.present();

    const { data, role } = await modal.onWillDismiss();
  }
}
