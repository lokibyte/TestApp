import { IonicModule } from '@ionic/angular';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Tab1Page } from './tab1.page';
import { ExploreContainerComponentModule } from '../explore-container/explore-container.module';

import { Tab1PageRoutingModule } from './tab1-routing.module';
import { VidIntroComponent } from '../components/videoResume/vid-intro/vid-intro.component';
import { VidPersonalComponent } from '../components/videoResume/vid-personal/vid-personal.component';
import { VidEducationalComponent } from '../components/videoResume/vid-educational/vid-educational.component';
import { VidSkillComponent } from '../components/videoResume/vid-skill/vid-skill.component';
import { VidExtraInfoComponent } from '../components/videoResume/vid-extra-info/vid-extra-info.component';
@NgModule({
  imports: [
    IonicModule,
    CommonModule,
    FormsModule,
    ExploreContainerComponentModule,
    Tab1PageRoutingModule
  ],
  declarations: [
    Tab1Page,
    // VidIntroComponent,
    // VidPersonalComponent,
    // VidEducationalComponent,
    // VidSkillComponent,
    // VidExtraInfoComponent
  ]
})
export class Tab1PageModule {}
