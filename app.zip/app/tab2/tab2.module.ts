import { IonicModule } from '@ionic/angular';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Tab2Page } from './tab2.page';


import { ExploreContainerComponentModule } from '../explore-container/explore-container.module';
import { VidIntroComponent } from '../components/videoResume/vid-intro/vid-intro.component';
import { VidPersonalComponent } from '../components/videoResume/vid-personal/vid-personal.component';
import { VidEducationalComponent } from '../components/videoResume/vid-educational/vid-educational.component';
import { VidSkillComponent } from '../components/videoResume/vid-skill/vid-skill.component';
import { VidExtraInfoComponent } from '../components/videoResume/vid-extra-info/vid-extra-info.component';
import { Tab2PageRoutingModule } from './tab2-routing.module';
import { VideoRecorderComponent } from '../components/video-recorder/video-recorder.component';
import { VideoPreviewComponent } from '../components/video-preview/video-preview.component';
@NgModule({
  imports: [
    IonicModule,
    CommonModule,
    FormsModule,
    ExploreContainerComponentModule,
    Tab2PageRoutingModule
  ],
  declarations: [
    Tab2Page,
    VidIntroComponent,
    VidPersonalComponent,
    VidEducationalComponent,
    VidSkillComponent,
    VidExtraInfoComponent,
    VideoRecorderComponent,
    VideoPreviewComponent
  ]
})
export class Tab2PageModule {}
