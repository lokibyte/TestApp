import { Component, OnInit } from '@angular/core';
import { MediaCapture, MediaFile, CaptureError, CaptureImageOptions,CaptureVideoOptions}  from '@awesome-cordova-plugins/media-capture/ngx'
import { Capacitor } from '@capacitor/core';

@Component({
  selector: 'app-vid-skill',
  templateUrl: './vid-skill.component.html',
  styleUrls: ['./vid-skill.component.scss'],
})
export class VidSkillComponent  implements OnInit {

  urlskillVideo='';
  constructor(public mediaCapture: MediaCapture) { }

  ngOnInit() {
    this.urlskillVideo = Capacitor.convertFileSrc(localStorage.getItem('skillvideo') || "")
    console.info("ngOnInit-skill");
    let vid = document.getElementById('skill-recorded');
    
    vid!.onloadstart=function(){
      alert("loadstart");
    }
    
    vid!.onloadeddata = function() {
      alert("Browser has loaded the current frame");
    };
  }

  recordSkillVideo(){
    console.info("recordSkillVideo");
    let me = this;
    let options: CaptureVideoOptions = { duration: 180 } //3mins
		    this.mediaCapture.captureVideo(options)
		    .then(
		      (data:any) => {
            // console.log(data);
            me.urlskillVideo = Capacitor.convertFileSrc(data[0].fullPath);
            localStorage.setItem('skillvideo',data[0].fullPath);
          },
		      (err) => console.error(err)
		    );
  }
  playVideo(){
    console.info("playVideo");
  }
  
  stopVideo(){
   console.info("stopVideo");
  }
}
