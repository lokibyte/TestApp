import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vid-intro',
  templateUrl: './vid-intro.component.html',
  styleUrls: ['./vid-intro.component.scss'],
})
export class VidIntroComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
